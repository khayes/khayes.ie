﻿using System;

namespace TurtleChallenge.Models
{
    public sealed class Turtle
    {
        public Turtle(Position position, Direction direction)
        {
            Position = position ?? throw new ArgumentNullException(nameof(position));
            Direction = direction;
        }

        public Position Position { get; private set; }

        public Direction Direction { get; private set; }

        public void MoveTo(Position position, Board board)
        {
            if (position == null)
            {
                throw new ArgumentNullException(nameof(position));
            }

            if (board == null)
            {
                throw new ArgumentNullException(nameof(board));
            }

            if (!position.IsWithinBounds(board))
            {
                throw new Exception("Position is not within the boards bounds.");
            }

            Position = position;
        }

        public Position CalculateForwardPosition()
        {
            var newXPosition = Position.X;
            var newYPosition = Position.Y;

            switch (Direction)
            {
                case Direction.North:
                    newYPosition -= 1;
                    break;

                case Direction.South:
                    newYPosition += 1;
                    break;

                case Direction.East:
                    newXPosition += 1;
                    break;

                case Direction.West:
                    newXPosition -= 1;
                    break;
            }

            return new Position(newXPosition, newYPosition);
        }

        public void Rotate90DegreesRight()
        {
            switch (Direction)
            {
                case Direction.North:
                    Direction = Direction.East;
                    break;

                case Direction.East:
                    Direction = Direction.South;
                    break;

                case Direction.South:
                    Direction = Direction.West;
                    break;

                case Direction.West:
                    Direction = Direction.North;
                    break;
            }
        }
    }
}

﻿using System;

namespace TurtleChallenge.Models
{
    public sealed class Mine
    {
        public Mine(Position position)
        {
            Position = position ?? throw new ArgumentNullException(nameof(position));
        }

        public Position Position { get; }
    }
}

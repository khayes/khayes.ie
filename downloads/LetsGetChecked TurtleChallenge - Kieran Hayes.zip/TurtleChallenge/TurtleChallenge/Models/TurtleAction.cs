﻿namespace TurtleChallenge.Models
{
    public enum TurtleAction
    {
        MoveForward,
        Rotate90DegreesRight
    }
}

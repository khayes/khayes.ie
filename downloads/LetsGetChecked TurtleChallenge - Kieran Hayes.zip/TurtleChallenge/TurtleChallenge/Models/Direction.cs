﻿namespace TurtleChallenge.Models
{
    public enum Direction
    {
        North,
        East,
        South,
        West
    }
}

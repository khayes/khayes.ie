﻿using System;

namespace TurtleChallenge.Models
{
    public sealed class Position
    {
        public Position(int x, int y)
        {
            X = x;
            Y = y;
        }

        public int X { get; set; }

        public int Y { get; set; }

        public override bool Equals(object obj)
        {
            return obj is Position position && X == position.X && Y == position.Y;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(X, Y);
        }

        public bool IsWithinBounds(Board board)
        {
            if (board == null)
            {
                throw new ArgumentNullException(nameof(board));
            }

            var isWithinXBounds = X >= 0 && X <= board.Width;
            var isWithinYBounds = Y >= 0 && Y <= board.Height;
            var isWithinBounds = isWithinXBounds && isWithinYBounds;

            return isWithinBounds;
        }
    }
}

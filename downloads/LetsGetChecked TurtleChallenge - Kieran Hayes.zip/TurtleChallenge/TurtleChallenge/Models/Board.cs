﻿using System;

namespace TurtleChallenge.Models
{
    public sealed class Board
    {
        public Board(uint width, uint height)
        {
            if (width < 1)
            {
                throw new ArgumentException("Width must be at least one.", nameof(width));
            }

            if (height < 1)
            {
                throw new ArgumentException("Height must be at least one.", nameof(height));
            }

            Width = width;
            Height = height;
        }

        public uint Width { get; }

        public uint Height { get; }
    }
}

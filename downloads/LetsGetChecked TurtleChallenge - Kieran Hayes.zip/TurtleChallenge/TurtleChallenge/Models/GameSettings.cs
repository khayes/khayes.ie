﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TurtleChallenge.Models
{
    public sealed class GameSettings
    {
        public GameSettings(
            uint boardWidth,
            uint boardHeight,
            Position startPosition,
            Direction startDirection,
            Position exitPosition,
            IEnumerable<Mine> mines)
        {
            BoardWidth = boardWidth;
            BoardHeight = boardHeight;
            StartPosition = startPosition ?? throw new ArgumentNullException(nameof(startPosition));
            StartDirection = startDirection;
            ExitPosition = exitPosition ?? throw new ArgumentNullException(nameof(exitPosition));
            Mines = mines?.ToArray();
        }

        public uint BoardWidth { get; }

        public uint BoardHeight { get; }

        public Position StartPosition { get; }

        public Direction StartDirection { get; }

        public Position ExitPosition { get; }

        public Mine[] Mines { get; }
    }
}

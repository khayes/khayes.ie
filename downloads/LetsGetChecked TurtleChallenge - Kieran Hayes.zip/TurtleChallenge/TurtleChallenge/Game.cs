﻿using System;
using System.Collections.Generic;
using System.Linq;
using TurtleChallenge.Logging;
using TurtleChallenge.Models;

namespace TurtleChallenge
{
    public sealed class Game
    {
        public Game(GameSettings gameSettings)
        {
            if (gameSettings == null)
            {
                throw new ArgumentNullException(nameof(gameSettings));
            }

            Board = new Board(gameSettings.BoardWidth, gameSettings.BoardHeight);
            Turtle = new Turtle(gameSettings.StartPosition, gameSettings.StartDirection);
            Exit = new Exit(gameSettings.ExitPosition);
            Mines = gameSettings.Mines;
        }

        public Board Board { get; }

        public Turtle Turtle { get; }

        public Exit Exit { get; }

        public Mine[] Mines { get; }

        public void RunActions(IEnumerable<TurtleAction> turtleActions, IGameLogger logger)
        {
            if (logger == null)
            {
                throw new ArgumentNullException(nameof(logger));
            }

            for (var i = 0; i < turtleActions.Count(); i ++)
            {
                var turtleAction = turtleActions.ElementAt(i);

                logger.Write($"Sequence {i + 1}: ");
                RunAction(turtleAction, logger);
                logger.Write(Environment.NewLine);
            }
        }

        public void RunAction(TurtleAction turtleAction, IGameLogger logger)
        {
            if (logger == null)
            {
                throw new ArgumentNullException(nameof(logger));
            }

            switch (turtleAction)
            {
                case TurtleAction.MoveForward:
                    var forwardPosition = Turtle.CalculateForwardPosition();
                    Turtle.MoveTo(forwardPosition, Board);
                    break;

                case TurtleAction.Rotate90DegreesRight:
                    Turtle.Rotate90DegreesRight();
                    break;
            }

            if (Turtle.Position.Equals(Exit.Position))
            {
                logger.Write("Success!");

                // No requirements were specified that if the turtle reaches the exit the game stops.
            }
            else if (Mines.Any(mine => Turtle.Position.Equals(mine.Position)))
            {
                logger.Write("Mine hit!");

                // No requirements were specified that if the turtle hits a mine the game stops.
            }
            else
            {
                logger.Write("Still in danger!");
            }
        }
    }
}

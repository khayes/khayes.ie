﻿namespace TurtleChallenge.Logging
{
    public interface IGameLogger
    {
        void Write(string value);
    }
}

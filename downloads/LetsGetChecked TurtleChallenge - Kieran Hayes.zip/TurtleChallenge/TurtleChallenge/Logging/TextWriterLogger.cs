﻿using System;
using System.IO;

namespace TurtleChallenge.Logging
{
    public sealed class TextWriterGameLogger : IGameLogger
    {
        private TextWriter _textWriter;

        public TextWriterGameLogger(TextWriter textWriter)
        {
            _textWriter = textWriter ?? throw new ArgumentNullException(nameof(textWriter));
        }

        public void Write(string value)
        {
            _textWriter.Write(value);
        }
    }
}

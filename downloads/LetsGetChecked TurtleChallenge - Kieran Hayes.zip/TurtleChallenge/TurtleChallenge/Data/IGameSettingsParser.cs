﻿using TurtleChallenge.Models;

namespace TurtleChallenge.Data
{
    public interface IGameSettingsParser
    {
        GameSettings Parse(string value);
    }
}
﻿using System;
using System.IO;
using System.Threading.Tasks;
using TurtleChallenge.Models;

namespace TurtleChallenge.Data
{
    public sealed class GameSettingsFileReader
    {
        private IGameSettingsParser _jsonParser;

        public GameSettingsFileReader(IGameSettingsParser jsonParser)
        {
            _jsonParser = jsonParser ?? throw new ArgumentNullException(nameof(jsonParser));
        }

        public async Task<GameSettings> ReadFileAsync(string filePath)
        {
            if (string.IsNullOrWhiteSpace(filePath))
            {
                throw new ArgumentNullException(nameof(filePath));
            }

            var fileContents = await ReadFileContentsAsync(filePath);
            var gameSettings = _jsonParser.Parse(fileContents);

            return gameSettings;
        }

        private async Task<string> ReadFileContentsAsync(string filePath)
        {
            if (string.IsNullOrWhiteSpace(filePath))
            {
                throw new ArgumentNullException(nameof(filePath));
            }

            using (var streamReader = File.OpenText(filePath))
            {
                return await streamReader.ReadToEndAsync();
            }
        }
    }
}

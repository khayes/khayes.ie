﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using TurtleChallenge.Models;

namespace TurtleChallenge.Data
{
    public sealed class TurtleActionsJsonParser : ITurtleActionsParser
    {
        public TurtleAction[] Parse(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new ArgumentNullException(nameof(value));
            }

            var jsonArray = JsonConvert.DeserializeObject<string[]>(value);
            var turtleActions = new List<TurtleAction>();

            foreach (var item in jsonArray)
            {
                switch (item?.ToLowerInvariant())
                {
                    case "m":
                        turtleActions.Add(TurtleAction.MoveForward);
                        break;

                    case "r":
                        turtleActions.Add(TurtleAction.Rotate90DegreesRight);
                        break;
                }
            }

            return turtleActions.ToArray();
        }
    }
}

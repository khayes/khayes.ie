﻿using Newtonsoft.Json;
using System;
using System.Linq;
using TurtleChallenge.Models;

namespace TurtleChallenge.Data
{
    public sealed class GameSettingsJsonParser : IGameSettingsParser
    {
        public GameSettings Parse(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new ArgumentNullException(nameof(value));
            }

            var json = JsonConvert.DeserializeObject<GameSettingsJson>(value);
            var gameSettings = json?.ToGameSettings();

            return gameSettings;
        }

        internal sealed class GameSettingsJson
        {
            [JsonProperty("Board", Required = Required.Always)]
            internal BoardObject Board { get; set; }

            [JsonProperty("Start", Required = Required.Always)]
            internal StartObject Start { get; set; }

            [JsonProperty("Exit", Required = Required.Always)]
            internal ExitObject Exit { get; set; }

            [JsonProperty("Mines", Required = Required.Always)]
            internal MineObject[] Mines { get; set; }

            internal GameSettings ToGameSettings()
            {
                return new GameSettings(boardWidth: Board.Width,
                                    boardHeight: Board.Height,
                                    startPosition: Start.Position,
                                    startDirection: Start.Direction,
                                    exitPosition: Exit.Position,
                                    mines: Mines.Select(i => i.ToModel()));
            }

            internal sealed class BoardObject
            {
                [JsonProperty("Width", Required = Required.Always)]
                public uint Width { get; set; }

                [JsonProperty("Height", Required = Required.Always)]
                public uint Height { get; set; }
            }

            internal class BoardPieceObject
            {
                [JsonProperty("X", Required = Required.Always)]
                public int X { get; set; }

                [JsonProperty("Y", Required = Required.Always)]
                public int Y { get; set; }

                public Position Position => new Position(X, Y);
            }

            internal sealed class StartObject : BoardPieceObject
            {
                [JsonProperty("Direction", Required = Required.Always)]
                public Direction Direction { get; set; }
            }

            internal sealed class ExitObject : BoardPieceObject
            {
            }

            internal sealed class MineObject : BoardPieceObject
            {
                public Mine ToModel()
                {
                    return new Mine(Position);
                }
            }
        }
    }
}

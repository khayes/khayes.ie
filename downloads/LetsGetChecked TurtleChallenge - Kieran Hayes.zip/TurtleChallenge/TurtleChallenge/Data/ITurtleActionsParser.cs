﻿using TurtleChallenge.Models;

namespace TurtleChallenge.Data
{
    public interface ITurtleActionsParser
    {
        TurtleAction[] Parse(string value);
    }
}
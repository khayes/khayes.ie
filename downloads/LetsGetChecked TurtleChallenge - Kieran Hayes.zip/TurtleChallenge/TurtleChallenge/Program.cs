﻿using System;
using System.Threading.Tasks;
using TurtleChallenge.Data;
using TurtleChallenge.Logging;
using TurtleChallenge.Models;

namespace TurtleChallenge
{
    class Program
    {
        static void Main(string[] args)
        {
            ValidateArgs(args);

            var gameSettingsFilePath = args[0];
            var movesFilePath = args[1];
            var gameSettingsTask = GetGameSettingsAsync(gameSettingsFilePath);
            var turtleActionsTask = GetTurtleActionsAsync(movesFilePath);

            try
            {
                Task.WhenAll(gameSettingsTask, turtleActionsTask).Wait();

                var gameSettings = gameSettingsTask.Result;
                var turtleActions = turtleActionsTask.Result;
                var game = new Game(gameSettings);
                var gameLogger = new TextWriterGameLogger(Console.Out);

                game.RunActions(turtleActions, gameLogger);
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;

                if (gameSettingsTask.IsFaulted)
                {
                    Console.WriteLine("Unable to get the game settings.");
                    Console.WriteLine(gameSettingsTask.Exception);   
                }
                else if (turtleActionsTask.IsFaulted)
                {
                    Console.WriteLine("Unable to get the move sequences.");
                    Console.WriteLine(turtleActionsTask.Exception);
                }
                else
                {
                    Console.WriteLine(ex);
                }

                Console.ResetColor();
            }

#if DEBUG
            Console.WriteLine("Game has finished running. Press any key to exit.");
            Console.ReadKey();
#endif
        }

        private static void ValidateArgs(string[] args)
        {
            if (args.Length < 2)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("You must supply a path to the game settings file, and a path to the moves file.");
                Console.ResetColor();
                Environment.Exit(-1);
            }
        }

        private static Task<GameSettings> GetGameSettingsAsync(string filePath)
        {
            var parser = new GameSettingsJsonParser();
            var reader = new GameSettingsFileReader(parser);

            return reader.ReadFileAsync(filePath);
        }

        private static Task<TurtleAction[]> GetTurtleActionsAsync(string filePath)
        {
            var parser = new TurtleActionsJsonParser();
            var reader = new TurtleActionsFileReader(parser);

            return reader.ReadFileAsync(filePath);
        }
    }
}

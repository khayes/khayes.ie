# About

This application has been built as .NET Core console application.  
The solution is made such that you can just open `TurtleChallenge.sln` with the latest Visual Studio 2017 and debug it.  
Includes are unit tests for the solution that will work with the in-built test runner with Visual Studio 2017 or via `dotnet test .\TurtleChallenge.UnitTests\`

## Creating an .exe

To create a new .exe you can either run `.\build.ps1` or the following command:

`dotnet publish TurtleChallenge -c Release -r win10-x64 -o ..\app\`

To then run the app you can either run `.\run.ps1` or the following command:

`.\app\TurtleChallenge.exe .\app\Data\Samples\game-settings .\app\Data\Samples\moves`

You can of course specify the appropriate path to your own files.

# Assumptions

1. No requirements have been outlined as to how to treat errors. I've opted to just write them to the console.
2. It has not been specified that there can only be one object per tile. For example can a mine by placed on the exit? Can two mines be placed on the same tile? In the interests of time I've opted to not handle these cases and *assume* the input files don't create such a scenario.
3. It has not been specified what should happen if the files are in a format that is not understood. In the interests of time I'm letting the errors bubble up to the console and give a generic human readable message for this.
4. It has not been specified what happens when the turtle is given an instruction to move outside of the bounds of the board. In this case I've opted to throw an exception, but the desired behaviour may be to simply not move the turtle.
5. It is presumed that all the sequences *always* run regardless of whether the turtle hits a mine or the exit. This assumption is based on the output of the example in the PDF where the turtle hits mines and the exit but the remaining sequences still continue.

# Closing Thoughts

My solution could be further refined, but I believe this meets the requirements sufficiently to submit as is.  

While implementing this solution I've chosen to demonstrate I understood concepts such as defensive coding and dependency injection. A DI container was deliberately not used to keep things simpler. I also could have created more abstractions such as around loading the data from other sources, but again opted not to in order to keep the solution simpler.
﻿using System;
using TurtleChallenge.Models;
using Xunit;

namespace TurtleChallenge.UnitTests.Models
{
    public sealed class ExitUnitTests
    {
        [Fact]
        public void Constructor_SetsPosition()
        {
            // Arrange
            var position = new Position(10, 20);

            // Act
            var exit = new Exit(position);

            // Assert
            Assert.Equal(position, exit.Position);
        }

        [Fact]
        public void Constructor_ThrowsArgumentNullException_IfPositionIsNull()
        {
            // Arrange
            Position position = null;

            // Act
            // Assert
            var exception = Assert.Throws<ArgumentNullException>(() => new Exit(position));

            Assert.Equal("position", exception.ParamName);
        }
    }
}

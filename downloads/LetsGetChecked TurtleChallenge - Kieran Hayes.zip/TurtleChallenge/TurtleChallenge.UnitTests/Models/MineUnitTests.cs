﻿using System;
using TurtleChallenge.Models;
using Xunit;

namespace TurtleChallenge.UnitTests.Models
{
    public sealed class MineUnitTests
    {
        [Fact]
        public void Constructor_SetsPosition()
        {
            // Arrange
            var position = new Position(10, 20);

            // Act
            var mine = new Mine(position);

            // Assert
            Assert.Equal(position, mine.Position);
        }

        [Fact]
        public void Constructor_ThrowsArgumentNullException_IfPositionIsNull()
        {
            // Arrange
            Position position = null;

            // Act
            // Assert
            var exception = Assert.Throws<ArgumentNullException>(() => new Mine(position));

            Assert.Equal("position", exception.ParamName);
        }
    }
}

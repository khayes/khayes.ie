using System;
using TurtleChallenge.Models;
using Xunit;

namespace TurtleChallenge.UnitTests.Models
{
    public sealed class BoardUnitTests
    {
        [Fact]
        public void Constructor_ThrowArgumentException_IfWidthIsZero()
        {
            // Arrange
            var width = 0u;
            var height = 12u;

            // Act
            var exception = Assert.Throws<ArgumentException>(() => new Board(width, height));

            // Assert
            Assert.Equal("width", exception.ParamName);
        }

        [Fact]
        public void Constructor_ThrowArgumentException_IfHeightIsZero()
        {
            // Arrange
            var width = 47u;
            var height = 0u;

            // Act
            var exception = Assert.Throws<ArgumentException>(() => new Board(width, height));

            // Assert
            Assert.Equal("height", exception.ParamName);
        }

        [Fact]
        public void Constructor_SetsWidth()
        {
            // Arrange
            var width = 10u;
            var height = 20u;

            // Act
            var board = new Board(width, height);

            // Assert
            Assert.Equal(width, board.Width);
        }

        [Fact]
        public void Constructor_SetsHeight()
        {
            // Arrange
            var width = 10u;
            var height = 20u;

            // Act
            var board = new Board(width, height);

            // Assert
            Assert.Equal(height, board.Height);
        }
    }
}

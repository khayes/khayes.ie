﻿using System;
using TurtleChallenge.Models;
using Xunit;

namespace TurtleChallenge.UnitTests.Models
{
    public sealed class TurtleUnitTests
    {
        [Fact]
        public void Constructor_SetsPosition()
        {
            // Arrange
            var position = new Position(12, 23);
            var direction = Direction.North;

            // Act
            var turtle = new Turtle(position, direction);

            // Assert
            Assert.Equal(position, turtle.Position);
        }

        [Fact]
        public void Constructor_SetsDirection()
        {
            // Arrange
            var position = new Position(12, 23);
            var direction = Direction.North;

            // Act
            var turtle = new Turtle(position, direction);

            // Assert
            Assert.Equal(direction, turtle.Direction);
        }

        [Fact]
        public void MoveTo_ThrowsArgumentNullException_IfPositionIsNull()
        {
            // Arrange
            var turtle = new Turtle(new Position(1, 2), Direction.North);
            Position position = null;
            var board = new Board(10, 20);

            // Act
            var exception = Assert.Throws<ArgumentNullException>(() => turtle.MoveTo(position, board));

            // Assert
            Assert.Equal("position", exception.ParamName);
        }

        [Fact]
        public void MoveTo_ThrowsArgumentNullException_IfBoardIsNull()
        {
            // Arrange
            var turtle = new Turtle(new Position(1, 2), Direction.North);
            var position = new Position(2, 4);
            Board board = null;

            // Act
            var exception = Assert.Throws<ArgumentNullException>(() => turtle.MoveTo(position, board));

            // Assert
            Assert.Equal("board", exception.ParamName);
        }

        [Fact]
        public void MoveTo_ThrowsException_IfPositionIsNotWithinBoard()
        {
            // Arrange
            var turtle = new Turtle(new Position(10, 10), Direction.North);
            var board = new Board(10, 20);
            var outOfBoundsPosition = new Position((int) board.Width + 1, (int) board.Height + 1);

            // Act
            var exception = Assert.Throws<Exception>(() => turtle.MoveTo(outOfBoundsPosition, board));

            // Assert
            Assert.Equal("Position is not within the boards bounds.", exception.Message);
        }

        [Fact]
        public void MoveTo_PositionIsUpdated()
        {
            // Arrange
            var turtle = new Turtle(new Position(0, 0), Direction.North);
            var board = new Board(50, 100);
            var newPosition = new Position(10, 20);

            // Act
            turtle.MoveTo(newPosition, board);

            // Assert
            Assert.Equal(newPosition, turtle.Position);
        }

        [Theory]
        [InlineData(5, 5, Direction.North, 5, 4)]
        [InlineData(5, 5, Direction.South, 5, 6)]
        [InlineData(5, 5, Direction.East, 6, 5)]
        [InlineData(5, 5, Direction.West, 4, 5)]
        public void CalculateForwardPosition_ReturnsExpectedPosition(int startX, int startY, Direction direction, int expectedX, int expectedY)
        {
            // Arrange
            var startPosition = new Position(startX, startY);
            var expectedPosition = new Position(expectedX, expectedY);
            var turtle = new Turtle(startPosition, direction);

            // Act
            var actualPosition = turtle.CalculateForwardPosition();

            // Assert
            Assert.Equal(expectedPosition, actualPosition);
        }

        [Theory]
        [InlineData(Direction.North, Direction.East)]
        [InlineData(Direction.East, Direction.South)]
        [InlineData(Direction.South, Direction.West)]
        [InlineData(Direction.West, Direction.North)]
        public void Rotate90DegreesRight_RotatesTurtleDirectionAsExpected(Direction startDirection, Direction expectedDirection)
        {
            // Arrange
            var turtle = new Turtle(new Position(0, 0), startDirection);

            // Act
            turtle.Rotate90DegreesRight();
            var actualDirection = turtle.Direction;

            // Assert
            Assert.Equal(expectedDirection, actualDirection);
        }
    }
}

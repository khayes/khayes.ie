﻿using System;
using TurtleChallenge.Models;
using Xunit;

namespace TurtleChallenge.UnitTests.Models
{
    public sealed class PositionUnitTests
    {
        [Fact]
        public void Constructors_SetsX()
        {
            // Arrange
            var x = 21;
            var y = 82;

            // Act
            var position = new Position(x, y);

            // Assert
            Assert.Equal(x, position.X);
        }

        [Fact]
        public void Constructors_SetsY()
        {
            // Arrange
            var x = 21;
            var y = 82;

            // Act
            var position = new Position(x, y);

            // Assert
            Assert.Equal(y, position.Y);
        }

        [Theory]
        [InlineData(1, 1, 1, 1, true)]
        [InlineData(1, 1, 1, 0, false)]
        [InlineData(1, 1, 0, 1, false)]
        [InlineData(1, 0, 1, 1, false)]
        [InlineData(0, 1, 1, 1, false)]
        public void Equals_DeterminesPositionEqualityAsExpected(int firstX, int firstY, int secondX, int secondY, bool expectedResult)
        {
            // Arrange
            var firstPosition = new Position(firstX, firstY);
            var secondPosition = new Position(secondX, secondY);

            // Act
            var actualResult = firstPosition.Equals(secondPosition);

            // Assert
            Assert.Equal(expectedResult, actualResult);
        }

        [Fact]
        public void IsWithinBounds_ThrowsArgumentNullException_IfBoardIsNull()
        {
            // Arrange
            var position = new Position(10, 20);
            Board board = null;

            // Act
            // Assert
            var exception = Assert.Throws<ArgumentNullException>(() => position.IsWithinBounds(board));

            Assert.Equal("board", exception.ParamName);
        }

        [Theory]
        [InlineData(10, 10, 0, 0, true)]
        [InlineData(10, 10, 10, 0, true)]
        [InlineData(10, 10, 0, 10, true)]
        [InlineData(10, 10, 10, 10, true)]
        public void IsWithinBounds_ReturnsAsExpected(uint width, uint height, int x, int y, bool expectedResult)
        {
            // Arrange
            var board = new Board(width, height);
            var position = new Position(x, y);

            // Act
            var actualResult = position.IsWithinBounds(board);

            // Assert
            Assert.Equal(expectedResult, actualResult);
        }
    }
}

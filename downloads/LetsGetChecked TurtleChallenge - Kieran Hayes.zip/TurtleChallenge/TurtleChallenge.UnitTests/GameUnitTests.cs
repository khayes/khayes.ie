﻿using System;
using System.Linq;
using TurtleChallenge.Data;
using TurtleChallenge.Logging;
using TurtleChallenge.Models;
using Xunit;

namespace TurtleChallenge.UnitTests
{
    public sealed class GameUnitTests
    {
        [Fact]
        public void Constructor_ThrowsArgumentNullException_IfGameSettingsINull()
        {
            // Arrange
            GameSettings gameSettings = null;

            // Act
            var exception = Assert.Throws<ArgumentNullException>(() => new Game(gameSettings));

            // Assert
            Assert.Equal("gameSettings", exception.ParamName);
        }

        [Fact]
        public void Constructor_CreatesBoardFromGameSettings()
        {
            // Arrange
            var boardWidth = 10u;
            var boardHeight = 20u;
            var startPosition = new Position(2, 4);
            var startDirection = Direction.North;
            var exitPosition = new Position(6, 1);
            var mines = new[]
            {
                new Mine(new Position(2, 4)),
                new Mine(new Position(6, 8))
            };
            var gameSettings = new GameSettings(boardWidth, boardHeight, startPosition, startDirection, exitPosition, mines);

            // Act
            var game = new Game(gameSettings);

            // Assert
            Assert.Equal(game.Board.Width, boardWidth);
            Assert.Equal(game.Board.Height, boardHeight);
        }

        [Fact]
        public void Constructor_CreatesTurtleFromGameSettings()
        {
            // Arrange
            var boardWidth = 10u;
            var boardHeight = 20u;
            var startPosition = new Position(2, 4);
            var startDirection = Direction.North;
            var exitPosition = new Position(6, 1);
            var mines = new[]
            {
                new Mine(new Position(2, 4)),
                new Mine(new Position(6, 8))
            };
            var gameSettings = new GameSettings(boardWidth, boardHeight, startPosition, startDirection, exitPosition, mines);

            // Act
            var game = new Game(gameSettings);

            // Assert
            Assert.Equal(game.Turtle.Position, startPosition);
            Assert.Equal(game.Turtle.Direction, startDirection);
        }

        [Fact]
        public void Constructor_CreatesExitFromGameSettings()
        {
            // Arrange
            var boardWidth = 10u;
            var boardHeight = 20u;
            var startPosition = new Position(2, 4);
            var startDirection = Direction.North;
            var exitPosition = new Position(6, 1);
            var mines = new[]
            {
                new Mine(new Position(2, 4)),
                new Mine(new Position(6, 8))
            };
            var gameSettings = new GameSettings(boardWidth, boardHeight, startPosition, startDirection, exitPosition, mines);

            // Act
            var game = new Game(gameSettings);

            // Assert
            Assert.Equal(game.Exit.Position, exitPosition);
        }

        [Fact]
        public void Constructor_CreatesMinesFromGameSettings()
        {
            // Arrange
            var boardWidth = 10u;
            var boardHeight = 20u;
            var startPosition = new Position(2, 4);
            var startDirection = Direction.North;
            var exitPosition = new Position(6, 1);
            var mines = new[]
            {
                new Mine(new Position(2, 4)),
                new Mine(new Position(6, 8))
            };
            var gameSettings = new GameSettings(boardWidth, boardHeight, startPosition, startDirection, exitPosition, mines);

            // Act
            var game = new Game(gameSettings);

            // Assert
            Assert.Equal(game.Mines, mines);
        }

        [Fact]
        public void RunAction_MoveForward_WillMoveTurtleToForwardPosition()
        {
            // Arrange
            var boardWidth = 10u;
            var boardHeight = 20u;
            var startPosition = new Position(2, 4);
            var startDirection = Direction.North;
            var exitPosition = new Position(6, 1);
            var mines = new[]
            {
                new Mine(new Position(2, 4)),
                new Mine(new Position(6, 8))
            };
            var gameSettings = new GameSettings(boardWidth, boardHeight, startPosition, startDirection, exitPosition, mines);
            var game = new Game(gameSettings);
            var gameLogger = new InMemoryGameLogger();
            var forwardPosition = game.Turtle.CalculateForwardPosition();

            // Act
            game.RunAction(TurtleAction.MoveForward, gameLogger);

            // Assert
            Assert.Equal(forwardPosition, game.Turtle.Position);
        }

        [Fact]
        public void RunAction_MoveForward_WillNotRotateTurtle()
        {
            // Arrange
            var boardWidth = 10u;
            var boardHeight = 20u;
            var startPosition = new Position(2, 4);
            var startDirection = Direction.North;
            var exitPosition = new Position(6, 1);
            var mines = new[]
            {
                new Mine(new Position(2, 4)),
                new Mine(new Position(6, 8))
            };
            var gameSettings = new GameSettings(boardWidth, boardHeight, startPosition, startDirection, exitPosition, mines);
            var game = new Game(gameSettings);
            var gameLogger = new InMemoryGameLogger();

            // Act
            game.RunAction(TurtleAction.MoveForward, gameLogger);

            // Assert
            Assert.Equal(startDirection, game.Turtle.Direction);
        }

        [Theory]
        [InlineData(Direction.North, Direction.East)]
        [InlineData(Direction.East, Direction.South)]
        [InlineData(Direction.South, Direction.West)]
        [InlineData(Direction.West, Direction.North)]
        public void RunAction_Rotate90DegreesRight_WillRotateTurtle(Direction startDirection, Direction expectedDirection)
        {
            // Arrange
            var boardWidth = 10u;
            var boardHeight = 20u;
            var startPosition = new Position(2, 4);
            var exitPosition = new Position(6, 1);
            var mines = new[]
            {
                new Mine(new Position(2, 4)),
                new Mine(new Position(6, 8))
            };
            var gameSettings = new GameSettings(boardWidth, boardHeight, startPosition, startDirection, exitPosition, mines);
            var game = new Game(gameSettings);
            var gameLogger = new InMemoryGameLogger();
            var forwardPosition = game.Turtle.CalculateForwardPosition();

            // Act
            game.RunAction(TurtleAction.Rotate90DegreesRight, gameLogger);

            // Assert
            Assert.Equal(expectedDirection, game.Turtle.Direction);
        }

        [Theory]
        [InlineData(Direction.North)]
        [InlineData(Direction.East)]
        [InlineData(Direction.South)]
        [InlineData(Direction.West)]
        public void RunAction_Rotate90DegreesRight_WillNotMoveTurtle(Direction startDirection)
        {
            // Arrange
            var boardWidth = 10u;
            var boardHeight = 20u;
            var startPosition = new Position(2, 4);
            var exitPosition = new Position(6, 1);
            var mines = new[]
            {
                new Mine(new Position(2, 4)),
                new Mine(new Position(6, 8))
            };
            var gameSettings = new GameSettings(boardWidth, boardHeight, startPosition, startDirection, exitPosition, mines);
            var game = new Game(gameSettings);
            var gameLogger = new InMemoryGameLogger();
            var forwardPosition = game.Turtle.CalculateForwardPosition();

            // Act
            game.RunAction(TurtleAction.Rotate90DegreesRight, gameLogger);

            // Assert
            Assert.Equal(startPosition, game.Turtle.Position);
        }

        [Fact]
        public void RunAction_IfTurtleMovedIntoExit_WillLogSuccess()
        {
            // Arrange
            var boardWidth = 10u;
            var boardHeight = 20u;
            var startPosition = new Position(2, 4);
            var startDirection = Direction.North;
            var exitPosition = new Position(startPosition.X, startPosition.Y - 1);
            var mines = new Mine[0];
            var gameSettings = new GameSettings(boardWidth, boardHeight, startPosition, startDirection, exitPosition, mines);
            var game = new Game(gameSettings);
            var gameLogger = new InMemoryGameLogger();

            // Act
            game.RunAction(TurtleAction.MoveForward, gameLogger);

            // Assert
            Assert.Equal("Success!", gameLogger.Log);
        }

        [Fact]
        public void RunAction_IfTurtleMovedIntoMine_WillLogMineHit()
        {
            // Arrange
            var boardWidth = 10u;
            var boardHeight = 20u;
            var startPosition = new Position(2, 4);
            var startDirection = Direction.North;
            var exitPosition = new Position(18, 19);
            var mines = new []
            {
                new Mine(new Position(startPosition.X, startPosition.Y - 1))
            };
            var gameSettings = new GameSettings(boardWidth, boardHeight, startPosition, startDirection, exitPosition, mines);
            var game = new Game(gameSettings);
            var gameLogger = new InMemoryGameLogger();

            // Act
            game.RunAction(TurtleAction.MoveForward, gameLogger);

            // Assert
            Assert.Equal("Mine hit!", gameLogger.Log);
        }

        [Fact]
        public void RunAction_IfTurtleMovedIntoSafeSpace_WillLogStillInDanger()
        {
            // Arrange
            var boardWidth = 10u;
            var boardHeight = 20u;
            var startPosition = new Position(2, 4);
            var startDirection = Direction.North;
            var exitPosition = new Position(18, 19);
            var mines = new Mine[0];
            var gameSettings = new GameSettings(boardWidth, boardHeight, startPosition, startDirection, exitPosition, mines);
            var game = new Game(gameSettings);
            var gameLogger = new InMemoryGameLogger();

            // Act
            game.RunAction(TurtleAction.MoveForward, gameLogger);

            // Assert
            Assert.Equal("Still in danger!", gameLogger.Log);
        }

        [Fact]
        public void RunAction_IfTurtleRotated90DegreesRightWhileAlreadyOnExit_WillLogSuccess()
        {
            // Arrange
            var boardWidth = 10u;
            var boardHeight = 20u;
            var startPosition = new Position(2, 4);
            var startDirection = Direction.North;
            var exitPosition = startPosition;
            var mines = new Mine[0];
            var gameSettings = new GameSettings(boardWidth, boardHeight, startPosition, startDirection, exitPosition, mines);
            var game = new Game(gameSettings);
            var gameLogger = new InMemoryGameLogger();

            // Act
            game.RunAction(TurtleAction.Rotate90DegreesRight, gameLogger);

            // Assert
            Assert.Equal("Success!", gameLogger.Log);
        }

        [Fact]
        public void RunAction_IfTurtleRotated90DegreesRightWhileAlreadyOnMine_WillLogMineHit()
        {
            // Arrange
            var boardWidth = 10u;
            var boardHeight = 20u;
            var startPosition = new Position(2, 4);
            var startDirection = Direction.North;
            var exitPosition = new Position(17, 18);
            var mines = new[]
            {
                new Mine(new Position(startPosition.X, startPosition.Y))
            };
            var gameSettings = new GameSettings(boardWidth, boardHeight, startPosition, startDirection, exitPosition, mines);
            var game = new Game(gameSettings);
            var gameLogger = new InMemoryGameLogger();

            // Act
            game.RunAction(TurtleAction.Rotate90DegreesRight, gameLogger);

            // Assert
            Assert.Equal("Mine hit!", gameLogger.Log);
        }

        [Fact]
        public void RunAction_IfTurtleRotated90DegreesRightWhileOnSafeSpace_WillLogStillInDanger()
        {
            // Arrange
            var boardWidth = 10u;
            var boardHeight = 20u;
            var startPosition = new Position(2, 4);
            var startDirection = Direction.North;
            var exitPosition = new Position(17, 18);
            var mines = new Mine[0];
            var gameSettings = new GameSettings(boardWidth, boardHeight, startPosition, startDirection, exitPosition, mines);
            var game = new Game(gameSettings);
            var gameLogger = new InMemoryGameLogger();

            // Act
            game.RunAction(TurtleAction.Rotate90DegreesRight, gameLogger);

            // Assert
            Assert.Equal("Still in danger!", gameLogger.Log);
        }

        [Fact]
        public void RunActions_WillLogSequences_LineByLine()
        {
            // Arrange
            var boardWidth = 10u;
            var boardHeight = 20u;
            var startPosition = new Position(2, 4);
            var startDirection = Direction.North;
            var exitPosition = new Position(17, 18);
            var mines = new Mine[0];
            var gameSettings = new GameSettings(boardWidth, boardHeight, startPosition, startDirection, exitPosition, mines);
            var game = new Game(gameSettings);
            var gameLogger = new InMemoryGameLogger();
            var turtleActions = new[] { TurtleAction.MoveForward, TurtleAction.Rotate90DegreesRight };

            // Act
            game.RunActions(turtleActions, gameLogger);

            // Assert
            var loggedLines = gameLogger.Log.Split(Environment.NewLine).Where(i => !string.IsNullOrWhiteSpace(i)).ToArray();

            Assert.Equal(loggedLines.Length, turtleActions.Length);
        }

        [Fact]
        public void RunActions_WillLogSequences_WithExpectedLineNumbers()
        {
            // Arrange
            var boardWidth = 10u;
            var boardHeight = 20u;
            var startPosition = new Position(2, 4);
            var startDirection = Direction.North;
            var exitPosition = new Position(17, 18);
            var mines = new Mine[0];
            var gameSettings = new GameSettings(boardWidth, boardHeight, startPosition, startDirection, exitPosition, mines);
            var game = new Game(gameSettings);
            var gameLogger = new InMemoryGameLogger();
            var turtleActions = new[] { TurtleAction.MoveForward, TurtleAction.Rotate90DegreesRight };

            // Act
            game.RunActions(turtleActions, gameLogger);

            // Assert
            var loggedLines = gameLogger.Log.Split(Environment.NewLine).Where(i => !string.IsNullOrWhiteSpace(i)).ToArray();

            for (var i = 0; i < loggedLines.Length; i++)
            {
                Assert.StartsWith($"Sequence {i + 1}: " , loggedLines[i]);
            }
        }

        [Fact]
        public void RunActions_WillLogExpectedSequences()
        {
            // Arrange
            var boardWidth = 5u;
            var boardHeight = 5u;
            var startPosition = new Position(0, 0);
            var startDirection = Direction.East;
            var exitPosition = new Position(0, 1);
            var mines = new []
            {
                new Mine(new Position(1, 1))
            };
            var gameSettings = new GameSettings(boardWidth, boardHeight, startPosition, startDirection, exitPosition, mines);
            var game = new Game(gameSettings);
            var gameLogger = new InMemoryGameLogger();
            var turtleActions = new[]
            {
                TurtleAction.MoveForward,
                TurtleAction.Rotate90DegreesRight,
                TurtleAction.MoveForward,
                TurtleAction.Rotate90DegreesRight,
                TurtleAction.MoveForward,
                TurtleAction.Rotate90DegreesRight
            };

            // Act
            game.RunActions(turtleActions, gameLogger);

            // Assert
            var loggedLines = gameLogger.Log.Split(Environment.NewLine).Where(i => !string.IsNullOrWhiteSpace(i)).ToArray();

            Assert.StartsWith(loggedLines[0], "Sequence 1: Still in danger!"); // Moved from 0,0 to 1,0
            Assert.StartsWith(loggedLines[1], "Sequence 2: Still in danger!"); // Rotated while still on 1,0
            Assert.StartsWith(loggedLines[2], "Sequence 3: Mine hit!"); // Moved from 1,0 to 1,1
            Assert.StartsWith(loggedLines[3], "Sequence 4: Mine hit!"); // Rotated while still on 1,1
            Assert.StartsWith(loggedLines[4], "Sequence 5: Success!"); // Moved from 1,1 to 0,1
            Assert.StartsWith(loggedLines[5], "Sequence 6: Success!"); // Rotated while still on 0,1
        }

        internal class InMemoryGameLogger : IGameLogger
        {
            public InMemoryGameLogger()
            {
                Log = string.Empty;
            }

            public void Write(string value)
            {
                Log += value;
            }

            public string Log { get; private set; }
        }
    }
}
